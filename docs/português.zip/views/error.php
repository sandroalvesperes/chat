<?
    $this->layout = 'chat';
?>

<div class="error-page">

    <div class="info-bar">
        Desculpe pelo inconveniente
    </div>

    <div class="error-panel">

        <img src="<?=URL::baseUrl();?>/public/images/error-default.png" alt="" />

        <p><?=@($this->message ? $this->message : 'Ocorreu um erro');?></p>

    </div>

</div>