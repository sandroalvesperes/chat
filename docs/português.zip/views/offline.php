<?
    $this->layout = 'chat';
    $this->js     = 'pages/offline.js';
    $this->widget->enable('radio');
    $this->widget->enable('toast');
?>

<div class="form-client">

    <p>
        <span>E-mail:</span>
        <input type="text" name="email" id="email" maxlength="120" class="form-input" autofocus="" />
    </p>

    <p>
        <span>Nome:</span>
        <input type="text" name="name" id="name" maxlength="60" class="form-input" />
    </p>

    <p unselectable="on" class="unselectable">
        <span>Sexo:</span>
        <input type="radio" name="sex" id="male" value="M" />
        <label for="male">Masculino</label> &nbsp; &nbsp;

        <input type="radio" name="sex" id="female" value="F" />
        <label for="female">Feminino</label>
    </p>

    <p>
        <span>Assunto:</span>
        <input type="text" name="subject" id="subject" maxlength="45" class="form-input" />
    </p>

    <p class="message">
        <span>Mensagem:</span>
        <textarea name="message" id="message" placeholder="Digite sua mensagem..." class="form-textarea"></textarea>
    </p>

    <p class="button">
        <button name="send_email" id="send_email" class="form-button"> Enviar e-mail </button>
    </p>

</div>