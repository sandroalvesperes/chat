<?
    $this->layout = 'chat';
?>

<div class="error-page">
    
    <div class="info-bar">
        Desculpe pelo inconveniente
    </div>
    
    <div class="error-panel">
        
        <img src="<?=URL::baseUrl();?>/public/images/error-404.png" alt="" />
        
        <p>Página não encontrada</p>
        
    </div>     
    
</div>