<?
    $this->layout = 'chat';
    $this->js     = 'pages/evaluate.js';
    $this->widget->enable('ui');
    $this->widget->enable('toast');
    $this->widget->enable('tipsy');
?>

<div class="evaluate">

    <div class="info-bar">
        Avalie nosso suporte
    </div>

    <div class="info-message">
        <img src="<?=URL::baseUrl();?>/public/images/support.png" alt="" />
        <p>
            A fim de melhorar nossos serviços<br />Por favor avalie esse atendimento
        </p>
    </div>

    <div class="rate-stars unselectable" unselectable="on">
        <ul>
            <li tip="Muito Ruim">&nbsp;</li>
            <li tip="Ruim">&nbsp;</li>
            <li tip="Médio">&nbsp;</li>
            <li tip="Bom">&nbsp;</li>
            <li tip="Excelente">&nbsp;</li>
        </ul>
    </div>

    <div class="button-group">
        <button id="evaluate" class="form-button" disabled="disabled"> Avaliar </button>
    </div>

</div>