<?
    $this->layout = 'chat';
    $this->js     = 'pages/waiting.js';
    $this->widget->enable('ui');
    $this->widget->enable('toast');
?>

<div class="waiting">

    <div class="floating-button-group">
        <button class="form-button cancel-button">Cancelar</button>
    </div>

    <div class="info-bar">
        Aguarde alguns minutos
    </div>

    <div class="info-message">
        <p>Por favor, aguarde por um de nossos operadores</p>
    </div>

    <div class="count-down">

        <div class="crossline"></div>

        <div class="middle-box">
            <div class="circle">&nbsp;</div>
            <span>clientes aguardando</span>
        </div>

    </div>

    <div class="waiting-operator"></div>

</div>