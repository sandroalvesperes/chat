<div class="form-user">
    <table>
        <tr>
            <td>Nome: *</td>
            <td>
                <input value="<?=htmlspecialchars($this->user['name']);?>" type="text" id="name" maxlength="50" class="form-input" size="50" />
            </td>
        </tr>
        <tr>
            <td>E-mail: *</td>
            <td>
                <input value="<?=htmlspecialchars($this->user['email']);?>" type="text" id="email" maxlength="120" class="form-input" size="50" />
            </td>
        </tr>
        <tr>
            <td>Sexo: *</td>
            <td>
                <input<?=($this->user['sex'] == 'M' ? ' checked="checked"' : '');?> type="radio" name="sex" id="male" value="M" />
                <label for="male">Masculino</label> &nbsp; &nbsp;

                <input<?=($this->user['sex'] == 'F' ? ' checked="checked"' : '');?> type="radio" name="sex" id="female" value="F" />
                <label for="female">Feminino</label>
            </td>
        </tr>
        <tr>
            <td>Senha:</td>
            <td>
                <input type="text" id="password" maxlength="20" class="form-input" size="25" />
            </td>
        </tr>
        <tr>
            <td>Situação: *</td>
            <td>
                <input<?=($this->user['active'] ? ' checked="checked"' : '');?> type="checkbox" id="user_status" value="1" />
            </td>
        </tr>
    </table>

    <fieldset>
        <legend> Permissão de Acesso </legend>

        <input<?=($this->user['maintain_user'] ? ' checked="checked"' : '');?> type="checkbox" id="maintain_user" value="1" />
        <label for="maintain_user">Manter Usuário</label> &nbsp;

        <input<?=($this->user['support_status'] ? ' checked="checked"' : '');?> type="checkbox" id="support_status" value="1" />
        <label for="support_status">Alterar Situação do Suporte</label>
    </fieldset>

</div>